# CS320GroupProject

## Instructions
### Linux
Run "make" in terminal

Open "localhost:8080/eric--web/index.html" in browser
### Windows
Run "make windows" in terminal

Open "localhost:8080/eric--web/index.html" in browser