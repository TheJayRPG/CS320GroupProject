Unit Tests

Run tests from inside Project directory (CS320GroupProject) using command

python3 -m tests.runner
